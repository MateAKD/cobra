(()=>{var e={};e.id=824,e.ids=[824],e.modules={3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},10356:()=>{},10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},44870:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},63092:()=>{},71671:(e,a,s)=>{"use strict";s.r(a),s.d(a,{patchFetch:()=>f,routeModule:()=>m,serverHooks:()=>x,workAsyncStorage:()=>u,workUnitAsyncStorage:()=>v});var i={};s.r(i),s.d(i,{POST:()=>g});var t=s(35304),o=s(56525),n=s(63516),r=s(86465),l=s(42944);let d=(e,a,s)=>{let i=new Date().toLocaleString("es-AR",{timeZone:"America/Argentina/Buenos_Aires",year:"numeric",month:"2-digit",day:"2-digit",hour:"2-digit",minute:"2-digit",second:"2-digit"});return`
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Notificaci\xf3n COBRA</title>
      <style>
        body {
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
          line-height: 1.6;
          color: #333;
          max-width: 600px;
          margin: 0 auto;
          padding: 20px;
          background-color: #f8f9fa;
        }
        .container {
          background: white;
          border-radius: 8px;
          padding: 30px;
          box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .header {
          text-align: center;
          border-bottom: 2px solid #e9ecef;
          padding-bottom: 20px;
          margin-bottom: 30px;
        }
        .logo {
          font-size: 24px;
          font-weight: bold;
          color: #2c3e50;
          margin-bottom: 10px;
        }
        .section {
          margin-bottom: 25px;
        }
        .section-title {
          font-size: 18px;
          font-weight: bold;
          color: #2c3e50;
          margin-bottom: 15px;
          padding-bottom: 5px;
          border-bottom: 1px solid #e9ecef;
        }
        .detail-row {
          display: flex;
          margin-bottom: 8px;
          padding: 5px 0;
        }
        .detail-label {
          font-weight: bold;
          color: #495057;
          min-width: 120px;
          margin-right: 10px;
        }
        .detail-value {
          color: #6c757d;
          flex: 1;
        }
        .action-badge {
          display: inline-block;
          padding: 4px 12px;
          border-radius: 20px;
          font-size: 12px;
          font-weight: bold;
          text-transform: uppercase;
        }
        .action-agregar { background: #d4edda; color: #155724; }
        .action-editar { background: #fff3cd; color: #856404; }
        .action-eliminar { background: #f8d7da; color: #721c24; }
        .action-ocultar { background: #e2e3e5; color: #383d41; }
        .action-mostrar { background: #cce5ff; color: #004085; }
        .action-agregar_horario { background: #d1ecf1; color: #0c5460; }
        .action-editar_horario { background: #d1ecf1; color: #0c5460; }
        .footer {
          margin-top: 30px;
          padding-top: 20px;
          border-top: 1px solid #e9ecef;
          text-align: center;
          color: #6c757d;
          font-size: 14px;
        }
        .system-info {
          background: #f8f9fa;
          padding: 15px;
          border-radius: 5px;
          margin-top: 20px;
        }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <div class="logo">🐍 COBRA</div>
          <p style="margin: 0; color: #6c757d;">Sistema de Notificaciones</p>
        </div>

        <div class="section">
          <div class="section-title">📋 Detalles del Cambio</div>
          
          <div class="detail-row">
            <span class="detail-label">Acci\xf3n:</span>
            <span class="detail-value">
              <span class="action-badge action-${e.toLowerCase()}">${e}</span>
            </span>
          </div>
          
          <div class="detail-row">
            <span class="detail-label">Producto:</span>
            <span class="detail-value"><strong>${a.name}</strong></span>
          </div>
          
          <div class="detail-row">
            <span class="detail-label">Descripci\xf3n:</span>
            <span class="detail-value">${a.description||"Sin descripci\xf3n"}</span>
          </div>
          
          <div class="detail-row">
            <span class="detail-label">Precio:</span>
            <span class="detail-value"><strong>$${a.price}</strong></span>
          </div>
          
          <div class="detail-row">
            <span class="detail-label">Secci\xf3n:</span>
            <span class="detail-value">${p(a.section)}</span>
          </div>
          
          <div class="detail-row">
            <span class="detail-label">Etiquetas:</span>
            <span class="detail-value">${a.tags?.join(", ")||"Sin etiquetas"}</span>
          </div>

          ${a.reason?`
          <div class="detail-row">
            <span class="detail-label">Motivo:</span>
            <span class="detail-value">${a.reason}</span>
          </div>
          `:""}

          ${a.hiddenBy?`
          <div class="detail-row">
            <span class="detail-label">${"OCULTAR"===e?"Ocultado por:":"Mostrado por:"}</span>
            <span class="detail-value">${a.hiddenBy}</span>
          </div>
          `:""}

          ${a.ingredients?`
          <div class="detail-row">
            <span class="detail-label">Ingredientes:</span>
            <span class="detail-value">${a.ingredients}</span>
          </div>
          `:""}

          ${a.glass?`
          <div class="detail-row">
            <span class="detail-label">Vaso:</span>
            <span class="detail-value">${a.glass}</span>
          </div>
          `:""}

          ${a.technique?`
          <div class="detail-row">
            <span class="detail-label">T\xe9cnica:</span>
            <span class="detail-value">${a.technique}</span>
          </div>
          `:""}

          ${a.garnish?`
          <div class="detail-row">
            <span class="detail-label">Garnish:</span>
            <span class="detail-value">${a.garnish}</span>
          </div>
          `:""}
        </div>

        <div class="system-info">
          <div class="section-title">📊 Informaci\xf3n del Sistema</div>
          
          <div class="detail-row">
            <span class="detail-label">Fecha y Hora:</span>
            <span class="detail-value">${i}</span>
          </div>
          
          <div class="detail-row">
            <span class="detail-label">User Agent:</span>
            <span class="detail-value">${s?.userAgent||"No disponible"}</span>
          </div>
          
          <div class="detail-row">
            <span class="detail-label">IP:</span>
            <span class="detail-value">${s?.ip||"No disponible"}</span>
          </div>
        </div>

        <div class="footer">
          <p>Este email fue generado autom\xe1ticamente por el Panel de Administraci\xf3n de COBRA.</p>
          <p><strong>Sistema de Notificaciones COBRA</strong></p>
        </div>
      </div>
    </body>
    </html>
  `},c=(e,a,s)=>{let i=new Date().toLocaleString("es-AR",{timeZone:"America/Argentina/Buenos_Aires",year:"numeric",month:"2-digit",day:"2-digit",hour:"2-digit",minute:"2-digit",second:"2-digit"});return`
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Notificaci\xf3n COBRA</title>
      <style>
        body {
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
          line-height: 1.6;
          color: #333;
          max-width: 600px;
          margin: 0 auto;
          padding: 20px;
          background-color: #f8f9fa;
        }
        .container {
          background: white;
          border-radius: 8px;
          padding: 30px;
          box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .header {
          text-align: center;
          border-bottom: 2px solid #e9ecef;
          padding-bottom: 20px;
          margin-bottom: 30px;
        }
        .logo {
          font-size: 24px;
          font-weight: bold;
          color: #2c3e50;
          margin-bottom: 10px;
        }
        .section {
          margin-bottom: 25px;
        }
        .section-title {
          font-size: 18px;
          font-weight: bold;
          color: #2c3e50;
          margin-bottom: 15px;
          padding-bottom: 5px;
          border-bottom: 1px solid #e9ecef;
        }
        .detail-row {
          display: flex;
          margin-bottom: 8px;
          padding: 5px 0;
        }
        .detail-label {
          font-weight: bold;
          color: #495057;
          min-width: 120px;
          margin-right: 10px;
        }
        .detail-value {
          color: #6c757d;
          flex: 1;
        }
        .action-badge {
          display: inline-block;
          padding: 4px 12px;
          border-radius: 20px;
          font-size: 12px;
          font-weight: bold;
          text-transform: uppercase;
        }
        .action-agregar_horario { background: #d1ecf1; color: #0c5460; }
        .action-editar_horario { background: #d1ecf1; color: #0c5460; }
        .footer {
          margin-top: 30px;
          padding-top: 20px;
          border-top: 1px solid #e9ecef;
          text-align: center;
          color: #6c757d;
          font-size: 14px;
        }
        .system-info {
          background: #f8f9fa;
          padding: 15px;
          border-radius: 5px;
          margin-top: 20px;
        }
        .time-range-info {
          background: #e7f3ff;
          padding: 15px;
          border-radius: 5px;
          border-left: 4px solid #0066cc;
          margin-top: 15px;
        }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <div class="logo">🐍 COBRA</div>
          <p style="margin: 0; color: #6c757d;">Sistema de Notificaciones</p>
        </div>

        <div class="section">
          <div class="section-title">⏰ Cambio de Horario de Categor\xeda</div>
          
          <div class="detail-row">
            <span class="detail-label">Acci\xf3n:</span>
            <span class="detail-value">
              <span class="action-badge action-${e.toLowerCase()}">${"AGREGAR_HORARIO"===e?"AGREGAR HORARIO":"EDITAR HORARIO"}</span>
            </span>
          </div>
          
          <div class="detail-row">
            <span class="detail-label">Categor\xeda:</span>
            <span class="detail-value"><strong>${a.categoryName}</strong></span>
          </div>
          
          <div class="detail-row">
            <span class="detail-label">ID de Categor\xeda:</span>
            <span class="detail-value">${a.categoryId}</span>
          </div>

          <div class="time-range-info">
            <div class="detail-row">
              <span class="detail-label">Restricci\xf3n Horaria:</span>
              <span class="detail-value"><strong>${a.timeRestricted?"✅ Activada":"❌ Desactivada"}</strong></span>
            </div>
            
            ${a.timeRestricted&&a.startTime&&a.endTime?`
            <div class="detail-row">
              <span class="detail-label">Horario de Inicio:</span>
              <span class="detail-value"><strong>${a.startTime}</strong></span>
            </div>
            
            <div class="detail-row">
              <span class="detail-label">Horario de Fin:</span>
              <span class="detail-value"><strong>${a.endTime}</strong></span>
            </div>
            
            <div class="detail-row" style="margin-top: 10px;">
              <span class="detail-label">Rango:</span>
              <span class="detail-value"><strong>🕐 ${a.startTime} - ${a.endTime}</strong></span>
            </div>
            `:`
            <div class="detail-row" style="margin-top: 10px;">
              <span class="detail-value">La categor\xeda se mostrar\xe1 en el men\xfa p\xfablico en todo momento.</span>
            </div>
            `}
          </div>
        </div>

        <div class="system-info">
          <div class="section-title">📊 Informaci\xf3n del Sistema</div>
          
          <div class="detail-row">
            <span class="detail-label">Fecha y Hora:</span>
            <span class="detail-value">${i}</span>
          </div>
          
          <div class="detail-row">
            <span class="detail-label">User Agent:</span>
            <span class="detail-value">${s?.userAgent||"No disponible"}</span>
          </div>
          
          <div class="detail-row">
            <span class="detail-label">IP:</span>
            <span class="detail-value">${s?.ip||"No disponible"}</span>
          </div>
        </div>

        <div class="footer">
          <p>Este email fue generado autom\xe1ticamente por el Panel de Administraci\xf3n de COBRA.</p>
          <p><strong>Sistema de Notificaciones COBRA</strong></p>
        </div>
      </div>
    </body>
    </html>
  `},p=e=>({parrilla:"Parrilla",guarniciones:"Guarniciones",tapeo:"Tapeo",milanesas:"Milanesas",hamburguesas:"Hamburguesas",ensaladas:"Ensaladas",otros:"Otros Platos",sandwicheria:"Sandwicher\xeda",postres:"Postres",cafeteria:"Cafeter\xeda",pasteleria:"Pasteler\xeda",bebidasSinAlcohol:"Bebidas Sin Alcohol",cervezas:"Cervezas",botellas:"Botellas",tragosClasicos:"Tragos Cl\xe1sicos",tragosEspeciales:"Tragos Especiales",tragosRedBull:"Tragos con Red Bull","vinos-tintos":"Vinos Tintos","vinos-blancos":"Vinos Blancos","vinos-rosados":"Vinos Rosados","vinos-copas":"Copas de Vino","promociones-cafe":"Promociones de Caf\xe9","promociones-tapeos":"Promociones de Tapeo","promociones-bebidas":"Promociones de Bebidas",tapas:"Tapas",panes:"Panes",tragos:"Tragos de Autor",clasicos:"Tragos Cl\xe1sicos",sinAlcohol:"Sin Alcohol"})[e]||e;async function g(e){try{let a,s;let{action:i,product:t,timeRange:o,userInfo:n}=await e.json(),p=process.env.RESEND_API_KEY||"re_AmDvZQtu_8qGJ2g3Ua2K4Dapwxb4VC5Fd";if(!p||""===p)return r.NextResponse.json({error:"RESEND_API_KEY no est\xe1 configurada correctamente"},{status:500});let g=new l.u(p),m=(process.env.RECIPIENT_EMAIL||"matepedace@gmail.com").split(",").map(e=>e.trim()).filter(e=>e.length>0),u="AGREGAR_HORARIO"===i||"EDITAR_HORARIO"===i;if(u){if(!o)return r.NextResponse.json({error:"timeRange es requerido para notificaciones de horario"},{status:400});a=c(i,o,n),s=`⏰ Cambio de Horario COBRA - ${o.categoryName}`}else{if(!t)return r.NextResponse.json({error:"product es requerido para notificaciones de producto"},{status:400});a=d(i,t,n),s=`🔔 Cambio en el Men\xfa COBRA - ${i}`}let v=[],x=[];for(let e=0;e<m.length;e++){let i=m[e];e>0&&await new Promise(e=>setTimeout(e,1e3));try{let e=await g.emails.send({from:"COBRA Restaurant <notificaciones@cobramenu.com>",to:i,subject:s,html:a});if(e.error){x.push({recipient:i,error:e.error.message||"Error desconocido de Resend"});continue}let t=e.data?.id||"unknown";v.push({recipient:i,id:t,success:!0})}catch(e){x.push({recipient:i,error:e instanceof Error?e.message:"Error desconocido"})}}let f={totalRecipients:m.length,successful:v.length,failed:x.length,results:v,errors:x.length>0?x:void 0};if(u&&o?(f.action=i,f.category=o.categoryName,f.timeRange=o.timeRestricted?`${o.startTime} - ${o.endTime}`:"Sin restricci\xf3n"):t&&(f.action=i,f.product=t.name),v.length>0)return r.NextResponse.json({success:!0,messageIds:v.map(e=>e.id),totalSent:v.length,totalFailed:x.length,errors:x.length>0?x:void 0});return r.NextResponse.json({success:!1,error:"No se pudo enviar ning\xfan email",errors:x},{status:500})}catch(e){return r.NextResponse.json({error:"Error al enviar notificaci\xf3n",details:e instanceof Error?e.message:"Error desconocido"},{status:500})}}let m=new t.AppRouteRouteModule({definition:{kind:o.RouteKind.APP_ROUTE,page:"/api/send-notification/route",pathname:"/api/send-notification",filename:"route",bundlePath:"app/api/send-notification/route"},resolvedPagePath:"C:\\Users\\Mateo\\Desktop\\AKDMIA\\Cobra 2.0\\app\\api\\send-notification\\route.ts",nextConfigOutput:"",userland:i}),{workAsyncStorage:u,workUnitAsyncStorage:v,serverHooks:x}=m;function f(){return(0,n.patchFetch)({workAsyncStorage:u,workUnitAsyncStorage:v})}},77598:e=>{"use strict";e.exports=require("node:crypto")}};var a=require("../../../webpack-runtime.js");a.C(e);var s=e=>a(a.s=e),i=a.X(0,[359,880,944],()=>s(71671));module.exports=i})();